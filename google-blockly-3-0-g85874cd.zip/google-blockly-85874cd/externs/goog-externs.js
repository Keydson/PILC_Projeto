/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Externs for goog.
 * @externs
 */

/**
 * @type {!Object}
 */
var goog = {};
